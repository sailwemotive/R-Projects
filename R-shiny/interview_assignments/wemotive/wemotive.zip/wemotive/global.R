# Loading data ----
questionnaire_data <- read.csv('./data/questionnaire.csv')

cnf.dev.df <- read.csv('./data/Corruption+and+Human+Development.csv')
